# Hands-On 2: Parallelization with OpenMP

*  Numeric integration
*  Image processing
*  Prime numbers